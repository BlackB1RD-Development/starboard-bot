module.exports = {
  name: 'ping',
  description: 'Pong 🏓',
  usage: 'ping',
  guildOnly: false,
  cooldown: '3',
  execute(client, message, args) {

  },
};